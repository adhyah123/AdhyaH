use std::time::SystemTime;
fn main() {
   // println!("{}",fib(5))
    for k in 0..51{
        println!("{}",k);
        let before = SystemTime::now();
        println!("{}",fib(k));
        let after = SystemTime::now();
        let difference = after.duration_since(before);
        let difference = difference.expect("Did the clock go back?");
        println!("Time it took: {:?}", difference)
    }
}
fn fib (k:u32) -> u128 {
    if k == 0 {
        0
    } else if k == 1 {
        1
    } else {
        fib(k - 2) + fib(k - 1)
    }
}


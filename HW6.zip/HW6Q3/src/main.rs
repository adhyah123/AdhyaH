use std::io;
fn main() {
    let mut input = String::new();
    io::stdin().read_line(&mut input).expect("Failed to read input");
    let k: u32 = input.trim().parse().expect("Invalid input. Please enter a non-negative integer.");

    let mut sum: u64 = 0;

    for i in 1..=k {
        let square: u64 = (i as u64).pow(2);
        sum += square;
    }
    
    println!("The sum of squares from 1 to {} is: {}", k, sum);
}

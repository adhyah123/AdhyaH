fn main() {
    const N: usize = 101;
    let mut fib_numbers: [u128; N] = [0; N];

    fib_numbers[0] = 0;
    fib_numbers[1] = 1;

    for i in 2..N {
        fib_numbers[i] = fib_numbers[i - 1] + fib_numbers[i - 2];
    }

    println!("{:?}", fib_numbers);
}
// fn main() {
//     const N: usize = 14;
//     let mut fib_numbers: [u8; N] = [0; N];

//     fib_numbers[0] = 0;
//     fib_numbers[1] = 1;

//     for i in 2..N {
//         fib_numbers[i] = fib_numbers[i - 1]+ (fib_numbers[i - 2]);
//     }
//         println!("{:?}", fib_numbers);

// }